#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
virtualenv -p /usr/bin/python3 $SCRIPT_DIR/venv
$SCRIPT_DIR/venv/bin/pip3 install -e '.[test]'


