import argparse
import os
from pymilvus import Collection, connections
import yaml
from urllib.parse import urlparse
import time
from datetime import datetime
import glob
import json


def parse_config_file(config_file, case_name):
    yaml_file = os.path.join('vectordb_bench/config-files', config_file)
    with open(yaml_file, 'r') as file:
        config = yaml.safe_load(file)
    collection_name = config[case_name]['custom_dataset_name']
    uri = config[case_name]['uri']
    parsed_uri = urlparse(uri)
    host = parsed_uri.hostname
    port = parsed_uri.port
    print(f"Milvus Host: {host}")
    print(f"Milvus Port: {port}")
    return host, port, collection_name


def get_index_type_from_milvus(collection_name, host, port):
    connections.connect("default", host=host, port=port)
    collection = Collection(name=collection_name)
    index_info = collection.index()
    index_type = None
    if index_info:
        index_params = index_info._index_params
        index_type = index_params['index_type']
        print(f"Index Type: {index_type}")
    else:
        print(f"Error: No index found for collection {collection_name}")
        exit(1)
    connections.disconnect("default")

    return index_type


def validate_index_type(config_file, case_name, search_param_name):
    if (case_name == 'milvusdiskann' or case_name == 'milvusaisaq') and search_param_name != 'search-list':
        print(f"Error: The search parameter for {case_name} should be search_list")
        exit(1)
    if case_name == 'milvushnsw' and search_param_name != 'ef-search':
        print(f"Error: The search parameter for {case_name} should be ef_search")
        exit(1)
    if case_name == 'milvusivfflat' and search_param_name != 'nprobe':
        print(f"Error: The search parameter for {case_name} should be nprobe")
        exit(1)
    host, port, collection_name = parse_config_file(config_file, case_name)
    index_type = get_index_type_from_milvus(collection_name, host, port)

    err_msg = f"Error: Collection {collection_name} has {index_type} index - not valid for case type {case_name} !!"
    if ((case_name == 'milvusdiskann' and index_type != 'DISKANN') or
            (case_name == 'milvusaisaq' and 'AISAQ' not in index_type) or
            (case_name == 'milvushnsw' and 'HNSW' not in index_type) or
            (case_name == 'milvusivfflat' and index_type != 'IVF_FLAT')):
        print(err_msg)
        exit(1)


def run_all(config_file, case_name, search_param_name, search_params):
    current_time = datetime.now()
    for search_param in search_params:
        command = 'python3 -m vectordb_bench.cli.vectordbbench ' + case_name + ' --config-file ' + config_file + ' --' + search_param_name + '=' + str(search_param)
        print(command)
        os.system(command)
    return current_time


def convert_results_files_for_bmchart_usage(target_time, output_path):
    qps_per_recall_points = []
    results_folder = 'vectordb_bench/results/Milvus/'
    file_pattern = results_folder + 'result_*_milvus.json'
    results_files = glob.glob(file_pattern)
    results_files.sort(key=os.path.getctime)
    search_param_name = None
    idx = 0

    for results_file in results_files:
        creation_time = os.path.getctime(results_file)
        if creation_time < target_time.timestamp():
            continue
        c_ti = time.ctime(creation_time)
        print(f"{results_file} creation_time: {c_ti}")
        for_bmchart = { "params": {}, "results": {}}
        with open(results_file, 'r') as file:
            data_dict = json.load(file)
        results = data_dict["results"]
        # timestamp = int(data_dict["timestamp"])
        metrics = results[0]["metrics"]
        task_config = results[0]["task_config"]
        recall = metrics["recall"]
        conc_qps_list = metrics["conc_qps_list"]
        conc_latency_p99_list = metrics["conc_latency_p99_list"]
        conc_latency_p95_list = metrics["conc_latency_p95_list"]
        conc_latency_avg_list = metrics["conc_latency_avg_list"]
        conc_qps = conc_qps_list[0]
        conc_latency_p99 = conc_latency_p99_list[0]
        conc_latency_p95 = conc_latency_p95_list[0]
        conc_latency_avg = conc_latency_avg_list[0]
        db_config = task_config["db_config"]
        db_label = db_config["db_label"]
        s0 = db_label.split(".")[0]
        s1 = s0.replace(":", "-")
        timestamp_str = s1.replace("T", "-")
        # print(timestamp_str)
        db_case_config = task_config["db_case_config"]
        case_config = task_config["case_config"]
        custom_case = case_config["custom_case"]
        dataset_config = custom_case["dataset_config"]
        collection_name = dataset_config["name"]
        results_params = for_bmchart["params"]
        results_params["dataset"] = collection_name
        results_params["experiment"] = custom_case["name"]
        results_params["engine"] = "milvus"
        results_params["top"] = case_config["k"]
        concurrency_search_config = case_config["concurrency_search_config"]
        num_concurrency = concurrency_search_config["num_concurrency"][0]
        results_params["parallel"] = num_concurrency
        collection_name = custom_case["name"]
        db_case_config_keys = db_case_config.keys()
        for key in db_case_config_keys:
            if key in ['search_list', 'ef', 'nprobe']:
                search_param_name = key
                break
        search_param = db_case_config[search_param_name]
        index_type = db_case_config["index"]
        results_params["config"] = {f"{search_param_name}": search_param}
        results_results = for_bmchart["results"]
        results_results["mean_precisions"] = recall
        results_results["rps"] = conc_qps
        results_results["p99_time"] = conc_latency_p99
        results_results["p95_time"] = conc_latency_p95
        results_results["mean_time"] = conc_latency_avg
        print(f"Recall: {recall}, QPS: {conc_qps}, {search_param_name}: {search_param}")
        point = (recall, conc_qps, search_param)
        qps_per_recall_points.append(point)
        json_object = json.dumps(for_bmchart, indent=2)
        if idx == 0:
            json_file_name = f'milvus-on-disk-{index_type}-default-{collection_name}-search-{timestamp_str}.json'
        else:
            json_file_name = f'milvus-on-disk-{index_type}-default-{collection_name}-search-{idx}-{timestamp_str}.json'
        fname = os.path.join(output_path, json_file_name)
        with open(fname, 'w') as fp:
            fp.write(json_object)
        idx = idx + 1


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument('--case', type=str, default='', help='milvus[index]', required=True, choices=['milvusdiskann', 'milvusaisaq', 'milvushnsw', 'milvusivfflat'])
    parser.add_argument('--config_file', type=str, default='milvus_config.yaml', help='yaml config file')
    parser.add_argument('--search_list', type=str, default=None, help='search_list for diskann')
    parser.add_argument('--ef_search', type=str, default=None, help='ef_search for hnsw_pq')
    parser.add_argument('--nprobe', type=str, default=None, help='nprobe for ivfflat')
    parser.add_argument('--out', type=str, default='.', help='full path where to copy output results json files')

    args = parser.parse_args()
    case_name = args.case
    config_file = args.config_file
    output_path = args.out
    if args.search_list is not None:
        search_params = args.search_list.split(",")
        search_param_name = 'search-list'
    elif args.ef_search is not None:
        search_params = args.ef_search.split(",")
        search_param_name = 'ef-search'
    elif args.nprobe is not None:
        search_params = args.nprobe.split(",")
        search_param_name = 'nprobe'
    else:
        print(f"Error: The search parameter is mandatory - search_list, ef_search or nprobe")
        exit(1)
    validate_index_type(config_file, case_name, search_param_name)
    print(search_params)
    start_time = run_all(config_file, case_name, search_param_name, search_params)
    print('Convert results json files for bmchart usage into ' +output_path)
    convert_results_files_for_bmchart_usage(start_time, output_path)


if __name__ == "__main__":
    main()
