import argparse
import pandas as pd
import numpy
import struct


def fbin_to_parquet(fbin_file, parquet_file, num_queries):
    with open(fbin_file, 'rb') as binary_file:
        # Read the number of vectors and their dimensions
        num_vectors = struct.unpack('i', binary_file.read(4))[0]  # Number of vectors (int)
        vector_dim = struct.unpack('i', binary_file.read(4))[0]   # Dimension of each vector (int)
        # Initialize a list to hold vectors
        vectors = []
        num_vectors_to_do = min(num_queries, num_vectors)
        print('vector_dim: {}, num_vectors: {}, num_vectors_to_do: {}'.format(vector_dim, num_vectors, num_vectors_to_do))
        for _ in range(num_vectors_to_do):
            # Read each vector as an array of floats
            vector_data = binary_file.read(vector_dim * 4)  # Each float is 4 bytes
            if not vector_data:
                break
            vector = struct.unpack('f' * vector_dim, vector_data)
            vectors.append(vector)
        query_ids = list(range(0, num_vectors_to_do))
        data = {
            'id': query_ids,
            'emb': vectors
        }
        df = pd.DataFrame(data)
        df.to_parquet(parquet_file, index=False)

        return query_ids


def create_parquet_with_neighbors(parquet_file, query_ids, neighbors):
    # Assuming query_ids is a list of IDs and
    # neighbors is a list of lists containing neighbor IDs
    data = {
        'id': query_ids,
        'neighbors_id': neighbors
    }
    df = pd.DataFrame(data)
    df.to_parquet(parquet_file, index=False)

# Example usage
# query_ids = [0, 1, 2]  # List of query vector IDs
# neighbors = [
#     [10, 11, 12],        # Neighbors for ID 0
#     [20, 21],            # Neighbors for ID 1
#     [30, 31, 32, 33]     # Neighbors for ID 2
# ]
def main():

    parser = argparse.ArgumentParser()
    parser.add_argument('--queries_file', type=str, required=True, default=None, help='queries fbin source file full path')
    parser.add_argument('--gt', type=str, required=True, default=None, help='groundtruth source file full path')
    parser.add_argument('--parquet_path', type=str, default='.', help='output neighbors.parquet full path')
    parser.add_argument('--num_queries', type=int, required=True, help='Number of queries to convert')
    args = parser.parse_args()
    gnd_file_name = args.gt
    queries_file = args.queries_file
    parquet_path = args.parquet_path
    num_queries = args.num_queries
    test_parquet_file = parquet_path + '/test.parquet'
    print('Convert ' + str(num_queries) + ' queries from ' +queries_file + ' to ' + test_parquet_file)
    query_ids = fbin_to_parquet(queries_file, test_parquet_file, num_queries)
    actual_num_queries = len(query_ids)
    neighbors_parquet_file = parquet_path + '/neighbors.parquet'
    print('Convert neighbors of ' + str(actual_num_queries) + ' queries from  ' + gnd_file_name + ' to ' + neighbors_parquet_file)
    gnd_file = open(gnd_file_name, 'rb')
    attrs = numpy.fromfile(gnd_file, count=2, dtype=numpy.int32)
    sz_query, max_k = attrs[0], attrs[1]
    print('sz_query: {}, max_k: {}, actual_num_queries: {}'.format(sz_query, max_k, actual_num_queries))
    if sz_query < actual_num_queries:
        print(f"Error: sz_query is lower from actual_num_queries")
        exit(1)
    data = numpy.fromfile(gnd_file, count=actual_num_queries * max_k, dtype=numpy.int32)
    arr_neighbors = numpy.reshape(data, [actual_num_queries, max_k])
    neighbors = []
    for query_neighbors in arr_neighbors:
        neighbors.append(query_neighbors)
    create_parquet_with_neighbors(neighbors_parquet_file, query_ids, neighbors)


if __name__ == "__main__":
    main()

