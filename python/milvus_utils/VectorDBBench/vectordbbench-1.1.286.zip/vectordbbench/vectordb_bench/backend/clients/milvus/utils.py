from pymilvus import Collection, DataType



def get_vector_field(collection:Collection) -> str:
    fields:[str] = []
    for field in collection.schema.fields:
        if hasattr(field, 'dim') and field.dim is not None and field.dtype in (DataType.FLOAT_VECTOR, DataType.BINARY_VECTOR):
            fields.append(field.name)
    if len(fields) == 1:
        return fields[0]
    if len(fields):
        print(f"We've identified multiple potential vector fields in the {collection.name} collection. Please select the correct one.")
        for i, option in enumerate(fields, 1):
            print(f"{i}. {option}")

        for _ in range(10):
            try:
                choice = int(input("Enter the number that identifies the correct choice: "))
                if 1 <= choice <= len(fields):
                    return fields[choice - 1]
                else:
                    print(f"Please enter a number between 1 and {len(fields)}.")
            except ValueError:
                print("Invalid input. Please enter a number.")
    print(f"Error: Failed to find vector fields in {collection.name} collection")
    exit(1)
